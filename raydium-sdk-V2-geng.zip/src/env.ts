

// const privateKey = '3suuWWvauy9aUbv7bzqxdQXqdRftSBmJ2FSi6WE7NSHpxTAAzgMZ8cGCgW33FToy47oJmYWQK9JjY9t5d1KbYczB' // platform owner keypair
// const privateKey = '67Kd14sftMJ4cqYCK5AyxzN7kKXjg5r9vxbh22qwkwvHK6BejPKy3HgTTQDiy9BpnyRvdwm6x8xvNazAkkYsdrwL' // platform2 owner keypair
// const privateKey = '3YejPKm5PmCDTWaAxFMcdGgy1qCo6FV54QgQ9f3unRX4S13nxAA9yqoLNwmF2ft2GytroyrWLwgiUnFuRgBDDN2y' // platform3 owner keypair
// const privateKey = '2hPv5DNMJ3UUPxC5sJtnrGCdt8zkBc4PsZcDvQfDdsJUqqdvLxt34m3kJnubPWptTMSHhXggdyAotU7Pp8rmLdEp' // platform4 owner keypair
const privateKey = '15hdJof871Xc2q8hwZ6wzEPc2MVaMq7MeXS6NKnjfZDTQ6rbnWkgCN9zhQdiEbHZufzmYosqzcwDxzJvjNxNmtM' // platform5 owner keypair
// const privateKey = '4upphKSDLpF9xoXfiX1HKxMaRmJNtx4osDmL8rwxvgBiugN284Yydk44VN8MY6Ro4YvUQ2oHPPkdtbYgnhB86tig' // mint owner keypair
// const privateKey = '2uR2YaRLP1Jf9ToXCXD22sm4nBbYoHGtgJqqrPtE3cxeAsW5ntgrzm8Pe8JXbGnt3kgYdc4unNzs1Q3R9YrDMjQf' // mint2 owner keypair
// const privateKey = '651T3EzMYcFWLWAL5bSFCs2hY24F3nfLfE35YrYf8AWsk2FQnXi7kLLUapLa2jKq4VedqHSqfM9Xer9qdSZwYM9A' // user keypair

// const grpcUrl = 'https://mainnet.helius-rpc.com/?api-key=cf609d92-4542-4de3-bde5-a5b25e2efbe2'
const grpcUrl = 'https://devnet.helius-rpc.com/?api-key=cf609d92-4542-4de3-bde5-a5b25e2efbe2'

export const GRPC_URL = grpcUrl
export const PRIVATE_KEY = privateKey